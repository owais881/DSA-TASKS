//#include<iostream>
//using namespace std;
//template<class T>
//class employee {
//public:
//	virtual T calculatedsalary() = 0;
//};
//template <class T>
//class fulltime :public employee<T> {
//private:
//	T fixed;
//public:
//	fulltime(T salary) {
//		fixed = salary;
//	}
//	T calculatedsalary() {
//		return fixed;
//	}
//};
//template<class T>
//class parttime :public employee<T> {
//private:
//	T hours;
//	T hoursrate;
//public:
//	parttime(T h, T hr) {
//		hours =h;
//		hoursrate = hr;
//	}
//	T calculatedsalary() {
//		return hours * hoursrate;
//	}
//};
//int main() {
//	double fixed, hours, hoursrate;
//	cout << "Enter the fixed price:";
//	cin >> fixed;
//	cout << "Enter the hours:";
//	cin >> hours;
//	cout << "Enter the hoursRate:";
//	cin >> hoursrate;
//	cout << endl;
//	fulltime<double> f(fixed);
//	parttime<double> p(hours, hoursrate);
//	cout << "Full time salary;" << f.calculatedsalary() << endl;
//	cout << "Part time salary;" << p.calculatedsalary() <<  endl;
//	return 0;
//}