//#include<iostream>
//using namespace std;
//
//class shape {
//public:
//	virtual double area()=0;
//};
//class circle :public shape {
//private:
//	double radius;
//public:
//	circle(double r) {
//		radius = r;
//	}	
//	double area() {
//		return 3.1416 * radius * radius;
//	}
//};
//class rectangle :public shape {
//private:
//	double lenght;
//	double width;
//public:
//	rectangle(double l, double w) {
//		lenght = l;
//		width = w;
//	}
//	double area() {
//		return lenght * width;
//	}
//};
//int main() {
//	circle c(4);
//	rectangle r(23, 45);
//
//	cout << "Circle area:" << c.area() << endl;
//	cout << "Rectangle area:" <<r.area() << endl;
//	return 0;
//}

